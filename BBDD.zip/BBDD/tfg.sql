-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tfg
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `carrito`
--

DROP TABLE IF EXISTS `carrito`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `carrito` (
  `id_carrito` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` int(11) DEFAULT 1,
  PRIMARY KEY (`id_carrito`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `carrito_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE,
  CONSTRAINT `carrito_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carrito`
--

LOCK TABLES `carrito` WRITE;
/*!40000 ALTER TABLE `carrito` DISABLE KEYS */;
/*!40000 ALTER TABLE `carrito` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorias` (
  `id_categoria` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `tipo` enum('ORDENADORES','CONSOLAS') NOT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (1,'Ordenadores','ORDENADORES'),(2,'Periféricos','ORDENADORES'),(3,'Componentes','ORDENADORES'),(4,'PlayStation','CONSOLAS'),(5,'PlayStation Pro','CONSOLAS'),(6,'Xbox','CONSOLAS'),(7,'Xbox Series','CONSOLAS'),(8,'Nintendo','CONSOLAS'),(9,'Nintendo OLED','CONSOLAS');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_pedido`
--

DROP TABLE IF EXISTS `detalle_pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle_pedido` (
  `id_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `id_pedido` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_detalle`),
  KEY `id_pedido` (`id_pedido`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `detalle_pedido_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`id_pedido`) ON DELETE CASCADE,
  CONSTRAINT `detalle_pedido_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_pedido`
--

LOCK TABLES `detalle_pedido` WRITE;
/*!40000 ALTER TABLE `detalle_pedido` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pedidos` (
  `id_pedido` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  `total` decimal(10,2) NOT NULL,
  `estado` enum('PENDIENTE','PAGADO','ENVIADO','ENTREGADO','CANCELADO') NOT NULL,
  PRIMARY KEY (`id_pedido`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos`
--

LOCK TABLES `pedidos` WRITE;
/*!40000 ALTER TABLE `pedidos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productos` (
  `id_producto` int(11) NOT NULL AUTO_INCREMENT,
  `id_categoria` int(11) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `stock` int(11) DEFAULT 0,
  `imagen` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_producto`),
  KEY `id_categoria` (`id_categoria`),
  CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

LOCK TABLES `productos` WRITE;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` VALUES (1,1,'PC Gaming Básico','Ryzen 5, RTX 3060',900.00,10,'pc1.png'),(2,1,'PC Gaming Pro','Ryzen 7, RTX 4070',1600.00,5,'pc2.png'),(3,1,'PC Oficina','i5, 16GB RAM',600.00,15,'pc3.png'),(4,1,'PC Extreme','i9, RTX 4090',3200.00,2,'pc4.png'),(5,2,'Ratón Gaming','16000 DPI RGB',50.00,30,'raton.png'),(6,2,'Teclado Mecánico','Switch Blue',80.00,20,'teclado.png'),(7,2,'Monitor 24\"','144Hz Full HD',200.00,10,'monitor.png'),(8,2,'Auriculares','Sonido 7.1',90.00,25,'auriculares.png'),(9,3,'RTX 4060','8GB GDDR6',450.00,6,'gpu.png'),(10,3,'Ryzen 7 5800X','8 núcleos',300.00,8,'cpu.png'),(11,3,'Placa Base B550','ATX',140.00,10,'placa.png'),(12,3,'Fuente 750W','80+ Gold',120.00,12,'fuente.png'),(13,4,'PlayStation 5','Con lector',550.00,10,'ps5.png'),(14,4,'Mando Dualsense Edge','Control oficial',70.00,30,'mando.png'),(15,4,'Base de carga','Doble mando',30.00,15,'base.png'),(16,4,'Auriculares Pulse','Audio 3D',100.00,12,'pulse.png'),(17,5,'Play Station 5 Pro','Edición Pro',700.00,6,'ps5pro.png'),(18,5,'Mando Dualsense V2','Gama alta',120.00,10,'mandopro.png'),(19,5,'SSD 2TB','Alta velocidad',200.00,8,'ssd.png'),(20,5,'Cámara HD','Streaming',80.00,5,'camara.png'),(21,6,'Xbox One','500GB',400.00,7,'xbox.png'),(22,6,'Mando Xbox','Inalámbrico',60.00,20,'mandoxbox.png'),(23,6,'Cargador','Batería recargable',25.00,30,'carga.png'),(24,6,'Auriculares Xbox','Gaming',90.00,10,'xboxaudio.png'),(25,7,'Xbox Series X','1TB',520.00,6,'seriesx.png'),(26,7,'Xbox Series S','512GB',320.00,8,'seriess.png'),(27,7,'Volante','Simulación',250.00,3,'volante.png'),(28,7,'Soporte vertical','Oficial',40.00,10,'soporte.png'),(29,8,'Nintendo Switch','Modelo base',300.00,12,'switch.png'),(30,8,'Joy-Con','Colores',80.00,20,'joycon.png'),(31,8,'Dock','Base TV',70.00,10,'dock.png'),(32,8,'Pro Controller','Control Pro',75.00,15,'pro.png'),(33,9,'Nintendo Switch OLED','Pantalla OLED',350.00,10,'oled.png'),(34,9,'Funda OLED','Protección',25.00,30,'funda.png'),(35,9,'Cristal templado','Protector',10.00,50,'cristal.png'),(36,9,'Soporte OLED','Ajustable',30.00,20,'soporteoled.png'),(38,9,'Soporte OLED','Ajustable',30.00,20,'soporteoled.png'),(39,9,'Cristal templado','Protector',10.00,50,'cristal.png'),(40,9,'Funda OLED','Protección',25.00,30,'funda.png'),(41,9,'Nintendo Switch OLED','Pantalla OLED',350.00,10,'oled.png'),(42,8,'Pro Controller','Control Pro',75.00,15,'pro.png'),(43,8,'Dock','Base TV',70.00,10,'dock.png'),(44,8,'Joy-Con','Colores',80.00,20,'joycon.png'),(45,8,'Nintendo Switch','Modelo base',300.00,12,'switch.png'),(46,7,'Soporte vertical','Oficial',40.00,10,'soporte.png'),(47,7,'Volante','Simulación',250.00,3,'volante.png'),(48,7,'Xbox Series S','512GB',320.00,8,'seriess.png'),(49,7,'Xbox Series X','1TB',520.00,6,'seriesx.png'),(50,6,'Auriculares Xbox','Gaming',90.00,10,'xboxaudio.png'),(51,6,'Cargador','Batería recargable',25.00,30,'carga.png'),(52,6,'Mando Xbox','Inalámbrico',60.00,20,'mandoxbox.png'),(53,6,'Xbox One','500GB',400.00,7,'xbox.png'),(54,5,'Cámara HD','Streaming',80.00,5,'camara.png'),(55,5,'SSD 2TB','Alta velocidad',200.00,8,'ssd.png'),(56,5,'Mando Dualsense V2','Gama alta',120.00,10,'mandopro.png'),(57,5,'Play Station 5 Pro','Edición Pro',700.00,6,'ps5pro.png'),(58,4,'Auriculares Pulse','Audio 3D',100.00,12,'pulse.png'),(59,4,'Base de carga','Doble mando',30.00,15,'base.png'),(60,4,'Mando Dualsense Edge','Control oficial',70.00,30,'mando.png'),(61,4,'PlayStation 5','Con lector',550.00,10,'ps5.png'),(62,3,'Fuente 750W','80+ Gold',120.00,12,'fuente.png'),(63,3,'Placa Base B550','ATX',140.00,10,'placa.png'),(64,3,'Ryzen 7 5800X','8 núcleos',300.00,8,'cpu.png'),(65,3,'RTX 4060','8GB GDDR6',450.00,6,'gpu.png'),(66,2,'Auriculares','Sonido 7.1',90.00,25,'auriculares.png'),(67,2,'Monitor 24\"','144Hz Full HD',200.00,10,'monitor.png'),(68,2,'Teclado Mecánico','Switch Blue',80.00,20,'teclado.png'),(69,2,'Ratón Gaming','16000 DPI RGB',50.00,30,'raton.png'),(70,1,'PC Extreme','i9, RTX 4090',3200.00,2,'pc4.png'),(71,1,'PC Oficina','i5, 16GB RAM',600.00,15,'pc3.png'),(72,1,'PC Gaming Pro','Ryzen 7, RTX 4070',1600.00,5,'pc2.png'),(73,1,'PC Gaming Básico','Ryzen 5, RTX 3060',900.00,10,'pc1.png'),(74,3,'Ryzen 7 5800X','8 núcleos',300.00,8,'cpu.png'),(75,4,'PlayStation 5','Con lector',550.00,10,'ps5.png'),(76,2,'Teclado Mecánico','Switch Blue',80.00,20,'teclado.png'),(77,7,'Soporte vertical','Oficial',40.00,10,'soporte.png'),(78,9,'Nintendo Switch OLED','Pantalla OLED',350.00,10,'oled.png'),(79,5,'Cámara HD','Streaming',80.00,5,'camara.png'),(80,8,'Dock','Base TV',70.00,10,'dock.png'),(81,7,'Xbox Series S','512GB',320.00,8,'seriess.png'),(82,6,'Cargador','Batería recargable',25.00,30,'carga.png'),(83,7,'Volante','Simulación',250.00,3,'volante.png'),(84,8,'Pro Controller','Control Pro',75.00,15,'pro.png'),(85,3,'Placa Base B550','ATX',140.00,10,'placa.png'),(86,3,'Fuente 750W','80+ Gold',120.00,12,'fuente.png'),(87,8,'Nintendo Switch','Modelo base',300.00,12,'switch.png'),(88,3,'RTX 4060','8GB GDDR6',450.00,6,'gpu.png'),(89,6,'Xbox One','500GB',400.00,7,'xbox.png'),(90,5,'Play Station 5 Pro','Edición Pro',700.00,6,'ps5pro.png'),(91,9,'Soporte OLED','Ajustable',30.00,20,'soporteoled.png'),(92,2,'Monitor 24\"','144Hz Full HD',200.00,10,'monitor.png'),(93,7,'Xbox Series X','1TB',520.00,6,'seriesx.png'),(94,1,'PC Gaming Básico','Ryzen 5, RTX 3060',900.00,10,'pc1.png'),(95,9,'Cristal templado','Protector',10.00,50,'cristal.png'),(96,4,'Mando Dualsense Edge','Control oficial',70.00,30,'mando.png'),(97,5,'SSD 2TB','Alta velocidad',200.00,8,'ssd.png'),(98,1,'PC Oficina','i5, 16GB RAM',600.00,15,'pc3.png'),(99,9,'Funda OLED','Protección',25.00,30,'funda.png'),(100,8,'Joy-Con','Colores',80.00,20,'joycon.png'),(101,6,'Mando Xbox','Inalámbrico',60.00,20,'mandoxbox.png'),(102,1,'PC Extreme','i9, RTX 4090',3200.00,2,'pc4.png'),(103,6,'Auriculares Xbox','Gaming',90.00,10,'xboxaudio.png'),(104,2,'Ratón Gaming','16000 DPI RGB',50.00,30,'raton.png'),(105,4,'Base de carga','Doble mando',30.00,15,'base.png'),(106,4,'Auriculares Pulse','Audio 3D',100.00,12,'pulse.png'),(107,5,'Mando Dualsense V2','Gama alta',120.00,10,'mandopro.png'),(108,1,'PC Gaming Pro','Ryzen 7, RTX 4070',1600.00,5,'pc2.png'),(109,2,'Auriculares','Sonido 7.1',90.00,25,'auriculares.png'),(110,9,'Nintendo Switch OLED','Pantalla OLED',350.00,10,'oled.png'),(111,3,'Ryzen 7 5800X','8 núcleos',300.00,8,'cpu.png'),(112,1,'PC Gaming Básico','Ryzen 5, RTX 3060',900.00,10,'pc1.png'),(113,7,'Volante','Simulación',250.00,3,'volante.png'),(114,8,'Joy-Con','Colores',80.00,20,'joycon.png'),(115,1,'PC Gaming Pro','Ryzen 7, RTX 4070',1600.00,5,'pc2.png'),(116,9,'Soporte OLED','Ajustable',30.00,20,'soporteoled.png'),(117,8,'Dock','Base TV',70.00,10,'dock.png'),(118,6,'Xbox One','500GB',400.00,7,'xbox.png'),(119,1,'PC Extreme','i9, RTX 4090',3200.00,2,'pc4.png'),(120,3,'Placa Base B550','ATX',140.00,10,'placa.png'),(121,5,'SSD 2TB','Alta velocidad',200.00,8,'ssd.png'),(122,2,'Teclado Mecánico','Switch Blue',80.00,20,'teclado.png'),(123,8,'Pro Controller','Control Pro',75.00,15,'pro.png'),(124,8,'Nintendo Switch','Modelo base',300.00,12,'switch.png'),(125,6,'Cargador','Batería recargable',25.00,30,'carga.png'),(126,4,'Mando Dualsense Edge','Control oficial',70.00,30,'mando.png'),(127,2,'Monitor 24\"','144Hz Full HD',200.00,10,'monitor.png'),(128,4,'Auriculares Pulse','Audio 3D',100.00,12,'pulse.png'),(129,5,'Cámara HD','Streaming',80.00,5,'camara.png'),(130,7,'Soporte vertical','Oficial',40.00,10,'soporte.png'),(131,5,'Mando Dualsense V2','Gama alta',120.00,10,'mandopro.png'),(132,6,'Mando Xbox','Inalámbrico',60.00,20,'mandoxbox.png'),(133,5,'Play Station 5 Pro','Edición Pro',700.00,6,'ps5pro.png'),(134,9,'Funda OLED','Protección',25.00,30,'funda.png'),(135,6,'Auriculares Xbox','Gaming',90.00,10,'xboxaudio.png'),(136,3,'RTX 4060','8GB GDDR6',450.00,6,'gpu.png'),(137,1,'PC Oficina','i5, 16GB RAM',600.00,15,'pc3.png'),(138,9,'Cristal templado','Protector',10.00,50,'cristal.png'),(139,2,'Ratón Gaming','16000 DPI RGB',50.00,30,'raton.png'),(140,2,'Auriculares','Sonido 7.1',90.00,25,'auriculares.png'),(141,4,'Base de carga','Doble mando',30.00,15,'base.png'),(142,3,'Fuente 750W','80+ Gold',120.00,12,'fuente.png'),(143,4,'PlayStation 5','Con lector',550.00,10,'ps5.png'),(144,7,'Xbox Series X','1TB',520.00,6,'seriesx.png'),(145,7,'Xbox Series S','512GB',320.00,8,'seriess.png');
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reparaciones`
--

DROP TABLE IF EXISTS `reparaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reparaciones` (
  `id_reparacion` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `apellidos` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `tipo_servicio` enum('REPARACION','MODIFICACION') NOT NULL,
  `dispositivo` varchar(100) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `presupuesto` decimal(10,2) DEFAULT NULL,
  `estado` enum('PENDIENTE','EN_PROCESO','FINALIZADO') NOT NULL,
  PRIMARY KEY (`id_reparacion`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reparaciones`
--

LOCK TABLES `reparaciones` WRITE;
/*!40000 ALTER TABLE `reparaciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `reparaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_usuario` varchar(60) NOT NULL,
  `nombres` varchar(255) DEFAULT NULL,
  `apellidos` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` enum('USER','ADMIN') DEFAULT 'USER',
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `nombre_usuario` (`nombre_usuario`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (16,'admin1','Luis','Juarez','admin1@gmail.com','$2a$10$BCCHQ39eIRsTZxG/I2trbOE/VufQ.1Hkyf9MN2W5zKiXq8FiLzqba','ADMIN','2026-03-19 18:07:51');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-20 21:27:26
